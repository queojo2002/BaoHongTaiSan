package com.example.baohongtaisan_2.Model;

public class DonVi {
    private String MaDV, TenDV, NgayCapNhat, NgayTao;


    public DonVi() {
    }

    public DonVi(String maDV, String tenDV, String ngayCapNhat, String ngayTao) {
        MaDV = maDV;
        TenDV = tenDV;
        NgayCapNhat = ngayCapNhat;
        NgayTao = ngayTao;
    }

    public String getNgayCapNhat() {
        return NgayCapNhat;
    }

    public void setNgayCapNhat(String ngayCapNhat) {
        NgayCapNhat = ngayCapNhat;
    }

    public String getNgayTao() {
        return NgayTao;
    }

    public void setNgayTao(String ngayTao) {
        NgayTao = ngayTao;
    }


    public String getTenDV() {
        return TenDV;
    }

    public void setTenDV(String tenDV) {
        TenDV = tenDV;
    }

    public String getMaDV() {
        return MaDV;
    }

    public void setMaDV(String maDV) {
        MaDV = maDV;
    }
}
