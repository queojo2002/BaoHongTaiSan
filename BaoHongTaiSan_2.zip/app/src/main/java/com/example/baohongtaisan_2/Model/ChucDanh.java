package com.example.baohongtaisan_2.Model;

public class ChucDanh {
    private String MaCD, TenCD, NgayCapNhat, NgayTao;


    public ChucDanh() {
    }

    public ChucDanh(String maCD, String tenCD, String ngayCapNhat, String ngayTao) {
        MaCD = maCD;
        TenCD = tenCD;
        NgayCapNhat = ngayCapNhat;
        NgayTao = ngayTao;
    }




    public String getTenCD() {
        return TenCD;
    }

    public void setTenCD(String tenCD) {
        TenCD = tenCD;
    }

    public String getNgayCapNhat() {
        return NgayCapNhat;
    }

    public void setNgayCapNhat(String ngayCapNhat) {
        NgayCapNhat = ngayCapNhat;
    }

    public String getNgayTao() {
        return NgayTao;
    }

    public void setNgayTao(String ngayTao) {
        NgayTao = ngayTao;
    }

    public String getMaCD() {
        return MaCD;
    }

    public void setMaCD(String maCD) {
        MaCD = maCD;
    }
}
