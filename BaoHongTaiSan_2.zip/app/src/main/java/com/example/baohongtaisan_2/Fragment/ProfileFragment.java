package com.example.baohongtaisan_2.Fragment;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.baohongtaisan_2.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;


public class ProfileFragment extends Fragment {

    TextInputEditText txtFullname_Edit, txtTenDangNhap_Edit, txtEmail_Edit;
    private ImageView imgProfile;
    private View view;
    private int KhoiTao = 0;
    private TextView a;
    private  FirebaseUser user;

    public ProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        user = FirebaseAuth.getInstance().getCurrentUser();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_profile, container, false);
        txtFullname_Edit = view.findViewById(R.id.Profile_txtFullname_Edit);
        txtTenDangNhap_Edit = view.findViewById(R.id.Profile_txtTenDangNhap_Edit);
        txtEmail_Edit = view.findViewById(R.id.Profile_txtEmail_Edit);
        imgProfile = view.findViewById(R.id.imgProfile_1);

        if (KhoiTao == 0)
        {
            KhoiTao = 1;
            txtFullname_Edit.setText(user.getDisplayName());
            txtEmail_Edit.setText(user.getEmail());
            txtTenDangNhap_Edit.setText(user.getEmail().substring(0, user.getEmail().indexOf("@")));
            Glide.with(this).load(user.getPhotoUrl()).error(R.drawable.logo_tdmu_2).into(imgProfile);
        }
        System.out.println("Testttt" + KhoiTao);
        return view;
    }



}