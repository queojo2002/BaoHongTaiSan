package com.example.baohongtaisan_2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.baohongtaisan_2.Fragment.BaoHongFragment;
import com.example.baohongtaisan_2.Fragment.ProfileFragment;
import com.example.baohongtaisan_2.Fragment.TraCuuFragment;
import com.example.baohongtaisan_2.Fragment.TrangChuFragment;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private TextView txt_Email, txt_FullName;
    private ImageView imgProfile;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private BottomNavigationView bottomNavigationView;
    private NavigationView navigationView;

    private String currentFrament_NAV = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        toolbar = findViewById(R.id.toolbar);
        bottomNavigationView = findViewById(R.id.bottom_nav);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerView = navigationView.getHeaderView(0);
        txt_FullName = headerView.findViewById(R.id.txtFullName);
        txt_Email = headerView.findViewById(R.id.txtEmail);
        imgProfile = headerView.findViewById(R.id.imgProfile);


        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Trang chủ");
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
             Open_NAV_TrangChu(0);
            navigationView.setCheckedItem(R.id.nav_trangchu);

        }


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.bottom_nav_home)
                {
                    Open_NAV_TrangChu(1);
                }else if (item.getItemId() == R.id.bottom_nav_gioithieu)
                {
                    Open_NAV_GioiThieu(1);
                }else if (item.getItemId() == R.id.bottom_nav_baohongthietbi)
                {
                    Open_NAV_BaoHongThietBi(1);
                }else if (item.getItemId() == R.id.bottom_nav_manager_info)
                {
                    Open_NAV_QuanLy_ThongTinCaNhan(1);
                }else if (item.getItemId() == R.id.bottom_nav_tracuu)
                {
                    Open_NAV_TraCuu(1);
                }
                return true;
            }
        });


    }



    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.nav_trangchu)
        {
            Open_NAV_TrangChu(0);
        }else if (item.getItemId() == R.id.nav_gioithieu)
        {
            Open_NAV_GioiThieu(0);
        }else if (item.getItemId() == R.id.nav_manager_info)
        {
            Open_NAV_QuanLy_ThongTinCaNhan(0);
        }else if (item.getItemId() == R.id.nav_manager_thietbi)
        {
            Open_NAV_QuanLy_ThongBaoThietBi(0);
        }else if (item.getItemId() == R.id.nav_baohong)
        {
            Open_NAV_BaoHongThietBi(0);
        }else if (item.getItemId() == R.id.nav_settings)
        {
            Open_NAV_CaiDat(0);
        }else if (item.getItemId() == R.id.nav_tracuu)
        {
            Open_NAV_TraCuu(0);
        }
        else if (item.getItemId() == R.id.nav_btnLogout)
        {
            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(getString(R.string.default_web_client_id))
                    .requestEmail()
                    .requestProfile()
                    .build();

            GoogleSignInClient mGoogle = GoogleSignIn.getClient(HomeActivity.this, googleSignInOptions);
            mGoogle.signOut();
            mAuth.signOut();
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            startActivity(intent);
            finishAffinity();
        }



        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    private void Open_NAV_TrangChu(int OptionNAV)
    {
        if (currentFrament_NAV != "nav_trangchu")
        {
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new TrangChuFragment()).commit();
            getSupportActionBar().setTitle("Trang chủ");
            currentFrament_NAV = "nav_trangchu";
            if (OptionNAV == 0) {
                bottomNavigationView.getMenu().findItem(R.id.bottom_nav_home).setChecked(true); // set menu bottom
            }else {
                navigationView.setCheckedItem(R.id.nav_trangchu);
            }
        }
    }

    private void Open_NAV_GioiThieu(int OptionNAV)
    {
        if (currentFrament_NAV != "nav_gioithieu")
        {
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new TrangChuFragment()).commit();
            getSupportActionBar().setTitle("Giới thiệu");
            currentFrament_NAV = "nav_gioithieu";
            if (OptionNAV == 0) {
                bottomNavigationView.getMenu().findItem(R.id.bottom_nav_gioithieu).setChecked(true); // set menu bottom
            }else {
                navigationView.setCheckedItem(R.id.nav_gioithieu);
            }
        }

    }

    private void Open_NAV_QuanLy_ThongTinCaNhan(int OptionNAV)
    {
        if (currentFrament_NAV != "nav_manager_info") {
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new ProfileFragment()).commit();
            getSupportActionBar().setTitle("Quản lý thông tin cá nhân");
            currentFrament_NAV = "nav_manager_info";
            if (OptionNAV == 0) {
                bottomNavigationView.getMenu().findItem(R.id.bottom_nav_manager_info).setChecked(true); // set menu bottom
            }else {
                navigationView.setCheckedItem(R.id.nav_manager_info);
            }
        }
    }

    private void Open_NAV_QuanLy_ThongBaoThietBi(int OptionNAV)
    {
        if (currentFrament_NAV != "nav_manager_thietbi") {
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new TrangChuFragment()).commit();
            getSupportActionBar().setTitle("Quản lý thông báo thiết bị");
            currentFrament_NAV = "nav_manager_thietbi";
            if (OptionNAV == 0) {
                bottomNavigationView.getMenu().findItem(R.id.bottom_nav_home).setChecked(true); // set menu bottom
            }else {
                navigationView.setCheckedItem(R.id.nav_trangchu);
            }
        }
    }

    private void Open_NAV_BaoHongThietBi(int OptionNAV)
    {
        if (currentFrament_NAV != "nav_baohong") {
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new BaoHongFragment()).commit();
            getSupportActionBar().setTitle("Báo hỏng thiết bị");
            currentFrament_NAV = "nav_baohong";
            if (OptionNAV == 0) {
                bottomNavigationView.getMenu().findItem(R.id.bottom_nav_baohongthietbi).setChecked(true); // set menu bottom
            }else {
                navigationView.setCheckedItem(R.id.nav_baohong);
            }
        }
    }

    private void Open_NAV_TraCuu(int OptionNAV)
    {
        if (currentFrament_NAV != "nav_tracuu") {
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new TraCuuFragment()).commit();
            getSupportActionBar().setTitle("Báo hỏng thiết bị");
            currentFrament_NAV = "nav_tracuu";
            if (OptionNAV == 0) {
                bottomNavigationView.getMenu().findItem(R.id.bottom_nav_tracuu).setChecked(true); // set menu bottom
            }else {
                navigationView.setCheckedItem(R.id.nav_trangchu);
            }
        }
    }


    private void Open_NAV_CaiDat(int OptionNAV)
    {
        if (currentFrament_NAV != "nav_settings") {
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new TrangChuFragment()).commit();
            getSupportActionBar().setTitle("Cài đặt gì đó !!!");
            currentFrament_NAV = "nav_settings";
            if (OptionNAV == 0) {
                bottomNavigationView.getMenu().findItem(R.id.bottom_nav_home).setChecked(true); // set menu bottom
            }else {
                navigationView.setCheckedItem(R.id.nav_trangchu);
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) finishAffinity();

        txt_FullName.setText(user.getDisplayName().toString());
        txt_Email.setText(user.getEmail().toString());
        Glide.with(this).load(user.getPhotoUrl()).error(R.drawable.logo_tdmu_2).into(imgProfile);
    }



}