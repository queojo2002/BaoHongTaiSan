package com.example.baohongtaisan_2.Model;

public class NguoiDung {
    private String MaND, MaCD, MaDV, MaPQ, HovaTen, Email, NgayCapNhat, NgayTao;


    public NguoiDung() {
    }

    public NguoiDung(String maND, String maCD, String maDV, String maPQ, String hovaTen, String email, String ngayCapNhat, String ngayTao) {
        MaND = maND;
        MaCD = maCD;
        MaDV = maDV;
        MaPQ = maPQ;
        HovaTen = hovaTen;
        Email = email;
        NgayCapNhat = ngayCapNhat;
        NgayTao = ngayTao;
    }



    public String getHovaTen() {
        return HovaTen;
    }

    public void setHovaTen(String hovaTen) {
        HovaTen = hovaTen;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getNgayCapNhat() {
        return NgayCapNhat;
    }

    public void setNgayCapNhat(String ngayCapNhat) {
        NgayCapNhat = ngayCapNhat;
    }

    public String getNgayTao() {
        return NgayTao;
    }

    public void setNgayTao(String ngayTao) {
        NgayTao = ngayTao;
    }

    public String getMaND() {
        return MaND;
    }

    public void setMaND(String maND) {
        MaND = maND;
    }

    public String getMaCD() {
        return MaCD;
    }

    public void setMaCD(String maCD) {
        MaCD = maCD;
    }

    public String getMaDV() {
        return MaDV;
    }

    public void setMaDV(String maDV) {
        MaDV = maDV;
    }

    public String getMaPQ() {
        return MaPQ;
    }

    public void setMaPQ(String maPQ) {
        MaPQ = maPQ;
    }
}
