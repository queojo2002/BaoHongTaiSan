package com.example.baohongtaisan_2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.baohongtaisan_2.Model.Config;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LoginActivity extends AppCompatActivity {

    private Button btnLogin;
    private GoogleSignInClient client;
    private GoogleSignInAccount account;

    private ProgressDialog progressDialog;

    FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = FirebaseFirestore.getInstance();
        progressDialog = new ProgressDialog(this);
        btnLogin = findViewById(R.id.btnLogin);
        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .requestProfile()
                .build();

        client = GoogleSignIn.getClient(LoginActivity.this, googleSignInOptions);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = client.getSignInIntent();
                startActivityForResult(intent, 99);
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 99)
        {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try{
                account = task.getResult(ApiException.class);
                AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
                progressDialog.show();
                FirebaseAuth.getInstance().signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            progressDialog.dismiss();
                            if (account.getEmail().toString().contains("@student.tdmu.edu.vn"))
                            {
                                _Check_Email_TonTai("1", "3", "1", account.getDisplayName(), account.getEmail());
                            }else {
                                Toast.makeText(LoginActivity.this, "Bạn phải đăng nhập bằng email của trường cấp !!!", Toast.LENGTH_SHORT).show();
                                client.signOut();
                                FirebaseAuth.getInstance().signOut();
                            }
                        }else {
                            Toast.makeText(LoginActivity.this, "Đăng nhập không thành công!!!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }catch (ApiException e){
                e.printStackTrace();
            }
        }
    }




    private void _Check_Email_TonTai(String MaCD, String MaDV, String MaPQ, String HoVaTen, String Email)
    {
        db.collection("NguoiDung").whereEqualTo("Email", Email)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isComplete())
                        {
                            if (task.getResult().size() <= 0) {
                                _Add_NguoiDung(MaCD, MaDV, MaPQ, HoVaTen, Email);
                            }
                            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                            startActivity(intent);
                            finishAffinity();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(LoginActivity.this, "Có lỗi khi đăng nhập vào hệ thống !!!", Toast.LENGTH_SHORT).show();
                        client.signOut();
                        FirebaseAuth.getInstance().signOut();
                    }
                });
    }

    private void _Add_NguoiDung(String MaCD, String MaDV, String MaPQ, String HoVaTen, String Email)
    {
        String MaND = UUID.randomUUID().toString();
        Map<String, Object> NguoiDung = new HashMap<>();
        NguoiDung.put("MaND", MaND);
        NguoiDung.put("MaCD", MaCD);
        NguoiDung.put("MaDV", MaDV);
        NguoiDung.put("MaPQ", MaPQ);
        NguoiDung.put("HoVaTen", HoVaTen);
        NguoiDung.put("Email", Email);
        NguoiDung.put("NgayCapNhat", Config.getInstance().getNgayHienTai());
        NguoiDung.put("NgayTao", Config.getInstance().getNgayHienTai());

        db.collection("NguoiDung").document(MaND).set(NguoiDung)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finishAffinity();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(LoginActivity.this, "Có lỗi khi đăng nhập vào hệ thống !!!!", Toast.LENGTH_SHORT).show();
                        client.signOut();
                        FirebaseAuth.getInstance().signOut();
                    }
                });
    }


}